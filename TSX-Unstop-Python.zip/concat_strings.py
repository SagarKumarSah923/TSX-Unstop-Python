str1 = "Hello, "
str2 = "World!"

result = str1 + str2

print(result)
