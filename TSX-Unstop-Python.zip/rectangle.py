# Define length and width variables
length = 10
width = 5

# Calculate area and perimeter
area = length * width
perimeter = 2 * (length + width)

# Print results
print("Area of rectangle:", area)
print("Perimeter of rectangle:", perimeter)
